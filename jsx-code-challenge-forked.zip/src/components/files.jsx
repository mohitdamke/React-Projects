import React from "react";

function Files() {
  return (
    <div className='note'>
      <h1>Hi All Of You</h1>
      <p>Hi my name is Mohit</p>;
    </div>
  );
}

export default Files;
