import React from "react";
import Header from "./header";
import Footer from "./footer";
import Files from "./files";

function app() {
  return (
    <div>
      <Header />
      <Files />
      <Footer />
    </div>
  );
}
export default app;
